Rails.application.routes.draw do
  root "labs#index"
  resources :labs
end
