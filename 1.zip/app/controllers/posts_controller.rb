class PostsController < ApplicationController
  def index

  end
end
